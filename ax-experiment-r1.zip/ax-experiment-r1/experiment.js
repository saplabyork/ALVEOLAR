// =====================================================================
// AX discrimination experiment, version r1: /aː/ only (jsPsych 7.3.4)
// Timeline: preload -> participant ID -> consent -> language questionnaire
// -> volume setting -> instructions -> 8 practice trials (feedback)
// -> 2 test blocks of 67 trials (break between) -> save data -> debrief
//
// URL options:
//   ?pid=12            set the participant ID (otherwise the experimenter types it)
//   ?simulate=visual   run through automatically with simulated key presses
//   ?simulate=data-only  same, instantly and without sound (for testing)
//
// Press Esc at any point to stop: the data so far are saved as ..._ABORTED.csv
// =====================================================================

const urlParams = new URLSearchParams(window.location.search);
const SIMULATE = urlParams.get("simulate"); // null, "visual" or "data-only"
const STIM_DIR = "stimuli/";
const DEFAULT_DURATION_S = 2.2; // used only if a sound's length can't be read

const state = {
  participant_id: urlParams.get("pid") || null,
  key_same: null,
  key_diff: null,
  durations: {}, // stimulus path -> duration in seconds
  saved: false,  // true once the data file has been saved
  queue: [], current: null, blockTotal: 0, blockDone: 0, // block runner
};

const jsPsych = initJsPsych({
  // Show the trial counter only on trial screens (fixation, sound, feedback)
  on_trial_start: (trial) => {
    counterEl.style.display = trial.show_counter ? "block" : "none";
  },
});

// Trial counter in the bottom-left corner ("x/y" within the current block)
const counterEl = document.createElement("div");
counterEl.id = "trial-counter";
counterEl.style.display = "none";
document.documentElement.appendChild(counterEl);

// Countdown clock in the upper-right corner (response window only)
const clockEl = document.createElement("div");
clockEl.id = "countdown";
clockEl.style.display = "none";
document.documentElement.appendChild(clockEl);
let clockTimer = null;
function startClock(soundMs) {
  stopClock();
  const t0 = performance.now();
  const tick = () => {
    const elapsed = performance.now() - t0;
    if (elapsed < soundMs) { clockEl.style.display = "none"; return; }
    const left = Math.max(0, soundMs + CONFIG.response_window_ms - elapsed);
    clockEl.textContent = Math.ceil(left / 1000);
    clockEl.style.display = "block";
  };
  tick();
  clockTimer = setInterval(tick, 50);
}
function stopClock() {
  if (clockTimer) clearInterval(clockTimer);
  clockTimer = null;
  clockEl.style.display = "none";
}

// Each block runs from a queue. A trial that times out is put back at the end
// of the queue, so it is repeated at the end of the same block (up to
// CONFIG.max_repeats extra times per trial).
const cur = () => state.current;
function nextFromQueue(prev) {
  // prefer a trial that shares no token with the one just played
  let idx = state.queue.findIndex((t) => !prev ||
    ![t.Token1_file, t.Token2_file].some((f) => f === prev.Token1_file || f === prev.Token2_file));
  if (idx === -1) idx = 0;
  return state.queue.splice(idx, 1)[0] || null;
}

// ---------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------

function setKeys(pid) {
  let sameIsF;
  if (CONFIG.key_mapping === "F_same") sameIsF = true;
  else if (CONFIG.key_mapping === "J_same") sameIsF = false;
  else {
    const n = parseInt(String(pid).replace(/\D/g, ""), 10);
    sameIsF = isNaN(n) ? Math.random() < 0.5 : n % 2 === 1;
  }
  state.key_same = sameIsF ? "f" : "j";
  state.key_diff = sameIsF ? "j" : "f";
  jsPsych.data.addProperties({
    experiment_version: "r1",
    participant_id: state.participant_id,
    key_same: state.key_same.toUpperCase(),
    key_diff: state.key_diff.toUpperCase(),
  });
}

function keyPrompt() {
  const left = state.key_same === "f"
    ? ["SAME", "F"] : ["DIFFERENT", "F"];
  const right = state.key_same === "f"
    ? ["DIFFERENT", "J"] : ["SAME", "J"];
  return `<div class="keys">
      <div class="keybox"><span class="key">${left[1]}</span><br>${left[0]}</div>
      <div class="keybox"><span class="key">${right[1]}</span><br>${right[0]}</div>
    </div>`;
}

function stimPath(trial) {
  return STIM_DIR + trial.Output_wav;
}

// Order one block's trials so that
//   - no more than 3 trials in a row share the same correct answer, and
//   - consecutive trials never share a token.
function orderBlock(trials) {
  const sharesToken = (a, b) =>
    a.Token1_file === b.Token1_file || a.Token1_file === b.Token2_file ||
    a.Token2_file === b.Token1_file || a.Token2_file === b.Token2_file;

  for (let attempt = 0; attempt < 5000; attempt++) {
    const pool = jsPsych.randomization.shuffle(trials.slice());
    const seq = [];
    let ok = true;
    while (pool.length) {
      const prev = seq[seq.length - 1];
      const run = seq.slice(-3);
      const idx = pool.findIndex((t) => {
        if (prev && sharesToken(prev, t)) return false;
        if (run.length === 3 && run.every((r) => r.Correct_response === t.Correct_response)) return false;
        return true;
      });
      if (idx === -1) { ok = false; break; }
      seq.push(pool.splice(idx, 1)[0]);
    }
    if (ok) return seq;
  }
  console.warn("Could not satisfy ordering constraints; using a plain shuffle.");
  return jsPsych.randomization.shuffle(trials.slice());
}

// ---------------------------------------------------------------------
// Trial building blocks
// ---------------------------------------------------------------------

const fixation = {
  type: jsPsychHtmlKeyboardResponse,
  stimulus: '<div class="fixation">+</div>',
  choices: "NO_KEYS",
  trial_duration: CONFIG.fixation_ms,
  data: { task: "fixation" },
  show_counter: true,
  on_start: () => {
    // Each trial starts with a fixation cross, so advance the counter here.
    // The total grows if timed-out trials are added back to the block.
    state.blockDone += 1;
    counterEl.textContent = state.blockDone + "/" + state.blockTotal;
  },
};

function axTrial(phase) {
  return {
    type: jsPsychAudioKeyboardResponse,
    stimulus: () => STIM_DIR + cur().Output_wav,
    choices: () => [state.key_same, state.key_diff],
    prompt: () => keyPrompt(),
    response_allowed_while_playing: false,
    trial_ends_after_audio: false,
    show_counter: true,
    trial_duration: () => {
      const p = STIM_DIR + cur().Output_wav;
      const d = state.durations[p] || DEFAULT_DURATION_S;
      return Math.round(d * 1000) + CONFIG.response_window_ms;
    },
    post_trial_gap: phase === "test" ? CONFIG.iti_ms : 0,
    data: () => ({
      task: phase === "test" ? "AX_test" : "AX_practice",
      block: cur().Block,
      Trial_ID: cur().Trial_ID,
      Trial_name: cur().Trial_name,
      Output_wav: cur().Output_wav,
      Condition: cur().Condition,
      Trial_type: cur().Trial_type,
      Contrast: cur().Contrast,
      Order: cur().Order,
      V1: cur().V1,
      Token1_file: cur().Token1_file,
      Token2_file: cur().Token2_file,
      Token1_cat: cur().Token1_cat,
      Token2_cat: cur().Token2_cat,
      correct_response: cur().Correct_response,
      attempt: cur().attempt,          // 1 = first presentation, 2+ = repeat after a timeout
      is_repeat: cur().attempt > 1,
    }),
    on_load: () => {
      const p = STIM_DIR + cur().Output_wav;
      startClock(Math.round((state.durations[p] || DEFAULT_DURATION_S) * 1000));
    },
    on_finish: (data) => {
      stopClock();
      const p = STIM_DIR + data.Output_wav;
      const durMs = Math.round((state.durations[p] || DEFAULT_DURATION_S) * 1000);
      data.stim_duration_ms = durMs;
      data.timed_out = data.response === null;
      data.key_pressed = data.response;
      data.response_label = data.response === null ? null
        : (jsPsych.pluginAPI.compareKeys(data.response, state.key_same) ? "same" : "different");
      data.correct = data.response_label === data.correct_response;
      data.rt_from_offset = data.rt === null ? null : Math.round(data.rt - durMs);
      delete data.response; // replaced by key_pressed / response_label
    },
  };
}

const practiceFeedback = {
  type: jsPsychHtmlKeyboardResponse,
  stimulus: () => {
    const last = jsPsych.data.get().last(1).values()[0];
    if (last.timed_out) return '<p class="fb slow">Too slow &mdash; please respond a little faster.</p>';
    return last.correct
      ? '<p class="fb good">Correct!</p>'
      : '<p class="fb bad">Incorrect</p>';
  },
  choices: "NO_KEYS",
  trial_duration: CONFIG.practice_feedback_ms,
  data: { task: "feedback" },
  show_counter: true,
};

const slowMessage = {
  timeline: [{
    type: jsPsychHtmlKeyboardResponse,
    stimulus: '<p class="fb slow">Please respond a little faster.</p>',
    choices: "NO_KEYS",
    trial_duration: CONFIG.slow_message_ms,
    data: { task: "slow_message" },
    show_counter: true,
  }],
  conditional_function: () => jsPsych.data.get().last(1).values()[0].timed_out === true,
};

// ---------------------------------------------------------------------
// Timeline
// ---------------------------------------------------------------------

const timeline = [];
const allStimuli = PRACTICE_TRIALS.concat(TEST_TRIALS).map(stimPath);
const volumeSample = STIM_DIR + (CONFIG.volume_sample || PRACTICE_TRIALS[0].Output_wav);

// 1. Preload all sounds
timeline.push({
  type: jsPsychPreload,
  audio: allStimuli.concat([volumeSample]),
  message: "<p>Loading sounds&hellip;</p>",
  show_detailed_errors: true,
  continue_after_error: false,
  max_load_time: 120000,
  error_message: "<p>Some sound files could not be loaded. Please tell the experimenter.</p>",
});

// 2. Read each sound's length (used to time the response window)
timeline.push({
  type: jsPsychCallFunction,
  async: true,
  func: (done) => {
    const paths = Array.from(new Set(allStimuli));
    Promise.all(paths.map((p) =>
      jsPsych.pluginAPI.getAudioBuffer(p)
        .then((buf) => { state.durations[p] = buf.duration; })
        .catch(() => {})
    )).then(() => done());
  },
  data: { task: "setup" },
});

// 3. Participant ID (skipped if ?pid= is in the URL)
timeline.push({
  timeline: [{
    type: jsPsychSurveyHtmlForm,
    preamble: "<p><b>Experimenter:</b> enter the participant ID.</p>",
    html: '<p><input name="pid" type="text" required autofocus style="font-size:20px;width:12em"></p>',
    button_label: "Start",
    data: { task: "participant_id" },
    on_finish: (data) => { state.participant_id = data.response.pid.trim(); },
  }],
  conditional_function: () => !state.participant_id,
});
timeline.push({
  type: jsPsychCallFunction,
  func: () => setKeys(state.participant_id),
  data: { task: "setup" },
});

// 4. Consent (PLACEHOLDER TEXT: replace with your approved consent form)
timeline.push({
  type: jsPsychHtmlButtonResponse,
  stimulus: `<div class="text">
    <h2>Consent to participate</h2>
    <p>Before commencing with the study, you will be asked to fill out a brief
    language-background questionnaire. We will then proceed with the listening
    experiment. You can withdraw at any point during the task by pressing the
    'ESC' key.</p>
    <p>By clicking <b>I agree</b>, you confirm that you have read the information
    above and agree to take part.</p>
  </div>`,
  choices: ["I agree", "I do not agree"],
  data: { task: "consent" },
  simulation_options: { data: { response: 0 } }, // simulated runs always agree
  on_finish: (data) => {
    data.consented = data.response === 0;
    if (data.response !== 0) {
      jsPsych.endExperiment('<div class="text"><p>Thank you. You have chosen not to take part, and no data will be used.</p><p>Please let the experimenter know.</p></div>');
    }
  },
});

// 5. Language background questionnaire
// Coded columns in the data:
//   q_born_in_canada: 1 = born in Canada, 0 = not born in Canada
//   q_home_language:  0 = English only, 1 = English and another language
//   q_home_language_other: the other language(s), typed (empty if English only)
// (skipped in ?simulate runs, because this plugin can't be simulated)
timeline.push({ timeline: [{
  type: jsPsychSurveyHtmlForm,
  preamble: '<h2>About you</h2>',
  html: `<div class="form">
    <label>Gender<br><input name="gender" type="text"></label>
    <label>Age (years)<br><input name="age" type="number" min="18" max="100" required></label>
    <label>Were you born in Canada?<br>
      <select name="born_in_canada" required>
        <option value="">Choose&hellip;</option>
        <option value="1">Yes, I was born in Canada</option>
        <option value="0">No, I was not born in Canada</option>
      </select></label>
    <label>Which language(s) are spoken at home?<br>
      <select name="home_language" id="home_language" required>
        <option value="">Choose&hellip;</option>
        <option value="0">English only</option>
        <option value="1">English and another language</option>
      </select></label>
    <label id="other_language_label" style="opacity:0.45">If English and another language: which other language(s)?<br>
      <input name="home_language_other" id="home_language_other" type="text" disabled></label>
  </div>`,
  button_label: "Continue",
  data: { task: "questionnaire" },
  on_load: () => {
    // The "other language" box is only active (and required) if
    // "English and another language" is chosen.
    const sel = document.getElementById("home_language");
    const box = document.getElementById("home_language_other");
    const lab = document.getElementById("other_language_label");
    sel.addEventListener("change", () => {
      const other = sel.value === "1";
      box.disabled = !other; box.required = other;
      lab.style.opacity = other ? "1" : "0.45";
      if (!other) box.value = "";
    });
  },
  on_finish: (data) => {
    const r = data.response;
    data.q_gender = r.gender || "";
    data.q_age = r.age === "" ? null : Number(r.age);
    data.q_born_in_canada = Number(r.born_in_canada);
    data.q_home_language = Number(r.home_language);
    data.q_home_language_other = r.home_language_other || "";
    delete data.response;
  },
}], conditional_function: () => !SIMULATE });

// 6. Volume setting (loops while the participant presses SPACE)
timeline.push({
  timeline: [{
    type: jsPsychAudioKeyboardResponse,
    stimulus: volumeSample,
    choices: [" ", "enter"],
    response_allowed_while_playing: false,
    prompt: `<div class="text"><h2>Setting the volume</h2>
      <p>Please put on the headphones. You will hear two short words.</p>
      <p>Adjust the volume so the sounds are clear and comfortable.</p>
      <p>Press <b>SPACE</b> to hear them again, or <b>ENTER</b> to continue.</p></div>`,
    data: { task: "volume" },
  }],
  loop_function: (data) => jsPsych.pluginAPI.compareKeys(data.values()[0].response, " "),
});

// 7. Instructions
timeline.push({
  type: jsPsychInstructions,
  pages: () => [
    `<div class="text"><h2>Instructions</h2>
      <p>On each trial you will hear two short made-up words, one after the other.</p>
      <p>Your job is to decide whether they are the <b>same word</b> or <b>different words</b>.</p>
      <p>The speaker said each word several times, so two recordings of the same word
      will not sound exactly identical. Decide whether they are the same <i>word</i>.</p></div>`,
    `<div class="text"><h2>Responding</h2>
      <p>After the second word, press one of these keys:</p>${keyPrompt()}
      <p>Keep your fingers on the F and J keys throughout. You can respond only after the
      second word has finished, and you then have <b>${CONFIG.response_window_ms / 1000} seconds</b>
      to answer. A countdown in the top-right corner shows the time left.</p>
      <p>If you don't answer in time, that trial will come back later in the same part.
      Respond as accurately as you can.</p></div>`,
    `<div class="text"><h2>Practice</h2>
      <p>First you will do a few practice trials. You will be told whether each answer
      was correct.</p><p>Click <b>Next</b> to begin the practice.</p></div>`,
  ],
  show_clickable_nav: true,
  data: { task: "instructions" },
});

// Runs one block: trials in the given order, then any timed-out trials again.
function runBlock(phase, trials) {
  const afterTrial = phase === "test" ? slowMessage : practiceFeedback;
  return [
    {
      type: jsPsychCallFunction,
      func: () => {
        state.queue = trials.map((t) => Object.assign({}, t, { attempt: 1 }));
        state.blockTotal = state.queue.length;
        state.blockDone = 0;
        state.current = state.queue.shift();
      },
      data: { task: "setup" },
    },
    {
      timeline: [fixation, axTrial(phase), afterTrial],
      loop_function: () => {
        const last = jsPsych.data.get().filterCustom((t) => t.task === "AX_test" || t.task === "AX_practice").last(1).values()[0];
        if (last && last.timed_out && state.current.attempt <= CONFIG.max_repeats) {
          state.queue.push(Object.assign({}, state.current, { attempt: state.current.attempt + 1 }));
          state.blockTotal += 1;
        }
        state.current = nextFromQueue(state.current);
        return state.current !== null;
      },
    },
  ];
}

// 8. Practice (8 trials, feedback)
timeline.push(...runBlock("practice", jsPsych.randomization.shuffle(PRACTICE_TRIALS.slice())));

timeline.push({
  type: jsPsychHtmlKeyboardResponse,
  stimulus: () => `<div class="text"><h2>Practice complete</h2>
    <p>Now the main part begins. It works the same way, but you will
    <b>no longer be told</b> whether your answers are correct.</p>
    <p>There are two parts with a short break in between. It takes about 10 minutes.</p>
    <p>Remember: you have <b>${CONFIG.response_window_ms / 1000} seconds</b> to answer after the second word.</p>
    ${keyPrompt()}
    <p>Press <b>SPACE</b> when you are ready.</p></div>`,
  choices: [" "],
  data: { task: "instructions" },
});

// 9. Test blocks
const block1 = orderBlock(TEST_TRIALS.filter((t) => t.Block === 1));
const block2 = orderBlock(TEST_TRIALS.filter((t) => t.Block === 2));

timeline.push(...runBlock("test", block1));
timeline.push({
  type: jsPsychHtmlKeyboardResponse,
  stimulus: `<div class="text"><h2>Break</h2>
    <p>You have finished the first part. Take a short rest.</p>
    <p>Press <b>SPACE</b> when you are ready to continue.</p></div>`,
  choices: [" "],
  data: { task: "break" },
});
timeline.push(...runBlock("test", block2));

// 10. Save data
timeline.push({
  type: jsPsychCallFunction,
  async: true,
  func: (done) => { saveData(false).then(() => done()); },
  data: { task: "setup" },
});

// 11. Debrief (PLACEHOLDER TEXT)
timeline.push({
  type: jsPsychHtmlButtonResponse,
  stimulus: `<div class="text"><h2>Thank you!</h2>
    <p><i>[PLACEHOLDER: insert the debriefing text here: the purpose of the study,
    how the tasks relate to it, how data are stored, and contact details for
    questions.]</i></p>
    <p>Your responses have been saved. Please let the experimenter know you have finished.</p></div>`,
  choices: ["Finish"],
  data: { task: "debrief" },
});

// ---------------------------------------------------------------------
// Saving (used at the end, and when the experiment is aborted with Esc)
// ---------------------------------------------------------------------
function saveData(aborted) {
  if (state.saved) return Promise.resolve();
  state.saved = true;

  // Number test trials within each block
  const counts = {};
  jsPsych.data.get().filter({ task: "AX_test" }).values().forEach((t) => {
    counts[t.block] = (counts[t.block] || 0) + 1;
    t.trial_in_block = counts[t.block];
  });
  jsPsych.data.addProperties({ aborted: aborted });

  const pid = state.participant_id || "noID";
  const stamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
  const filename = `AX_r1_${pid}_${stamp}${aborted ? "_ABORTED" : ""}.csv`;
  const keep = jsPsych.data.get().filterCustom((t) => !["fixation", "feedback", "setup"].includes(t.task));
  const csv = keep.csv();

  if (CONFIG.save_local_csv && SIMULATE !== "data-only") keep.localSave("csv", filename);
  window.__AX_LAST_CSV__ = { filename, csv }; // for testing

  if (!CONFIG.datapipe_experiment_id) return Promise.resolve();
  return fetch("https://pipe.jspsych.org/api/data/", {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "*/*" },
    body: JSON.stringify({ experimentID: CONFIG.datapipe_experiment_id, filename, data: csv }),
  }).catch(() => {});
}

// ---------------------------------------------------------------------
// Esc aborts the experiment: data so far are saved (file name ends in _ABORTED)
// ---------------------------------------------------------------------
document.addEventListener("keydown", (e) => {
  if (e.key !== "Escape" || state.aborting) return;
  state.aborting = true;
  const ctx = jsPsych.pluginAPI.audioContext();
  if (ctx && ctx.state === "running") ctx.suspend(); // stop any sound
  document.querySelectorAll("audio").forEach((a) => a.pause());
  counterEl.style.display = "none";
  stopClock();
  const alreadySaved = state.saved;
  saveData(true).then(() => {
    jsPsych.endExperiment(`<div class="text"><h2>Experiment stopped</h2>
      <p>${alreadySaved ? "The data were already saved." :
        "The responses so far have been saved (the file name ends in _ABORTED)."}</p></div>`);
  });
});

// ---------------------------------------------------------------------
// Run
// ---------------------------------------------------------------------
if (SIMULATE) {
  if (!state.participant_id) state.participant_id = "SIM" + Math.floor(Math.random() * 1000);
  jsPsych.simulate(timeline, SIMULATE);
} else {
  jsPsych.run(timeline);
}
